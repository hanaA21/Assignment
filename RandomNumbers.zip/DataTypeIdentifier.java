package Assignments;
import java.util.Random;

class RandomNumberss {
    private static final Random random = new Random();

    public static long generateRandomNumber(long min, long max) {
        return min + (long) (random.nextDouble() * (max - min + 1));
    }
}

