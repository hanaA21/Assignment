package Assignments;

public class name {
    public static void main(String[] args) {
        String s = "Hi\uD83D\uDC4B, My name is \"ሃና\".";
        System.out.println(s);
        System.out.println(s.length());

        // The size of the string is 22 because each character will count 1 and the emoji as two.
    }
}